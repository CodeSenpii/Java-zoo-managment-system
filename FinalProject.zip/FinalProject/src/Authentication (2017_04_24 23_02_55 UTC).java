import java.io.FileInputStream;
import java.util.Scanner;
import java.io.IOException; 
/**
 * This authentication class takes the username and hashed password.
 * it then looks up the username and hashed password in a text file.
 * access is granted to the user provided there is username and password
 * a user and corresponding password match.
 *
 * @author Kieyn Parks
 * @version 1.0
 *
 * @param accessGranted is the flag that indicates a successful logon
 * @param role is set when access is granted
 */

public class Authentication{

   private String userName;
   private String userPasswordHash;
   private FileInputStream fileByteStream;
   private Scanner inFS;
   private String role;
   private boolean accessGranted;
   
   
   public Authentication(){
      userName = "none";
      userPasswordHash = "none";
      role = "none";
      accessGranted = false;
   }
   
   public void setUserName(String uName){
      userName = uName;
   }
   public String getUserName(){
      return userName;
   }
   public void setPasswordHash(String pWord){
      userPasswordHash = pWord;
   }
   public String getPassWordHash(){
      return userPasswordHash;
   }
   
   public void setFileInputStream(FileInputStream fByte){
      fileByteStream = fByte;
   }
   public void setFS(Scanner inFS){
      this.inFS = inFS;
   }
   public String getRole(){
      return role;
   }
   public boolean getAccess(){
      return accessGranted;
   }
            
   public void print(){
      System.out.println(userName);
      System.out.println(userPasswordHash);
   }
   /*--------------File Handling---------------------*/
   /**
    * This function uses the credentials file object and assign the 
    * strings in each colomn to variables for comparison to the password hash
    * and username.
    *
    *@param strUser gets username in column one.
    *@param strHash gets the password hash from column 2
    *@param strRole gets the user role from column 3
    */
   public void Filo(){
   
      String strUser = "";
      String strHash = "";
      String strRole = "";
      String strPassWord = "";
            
      int strLen = 0;
      
      while(inFS.hasNext()){
          strUser = inFS.next();
          strHash = inFS.next();
          strPassWord = inFS.next();
          strRole = inFS.next();
                           
          if(strUser.equals(userName) && strHash.equals(userPasswordHash)){
             role = strRole;
             accessGranted = true;
             break;
          }
         else{
            continue;         }
     }
   }
}
