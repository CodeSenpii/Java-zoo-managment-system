import java.io.FileInputStream;
import java.io.IOException; 
import java.util.Scanner;
/**
 * This class will access the role files and print out the role for the coresponding user.
 * 
 * @author Kieyn Parks
 * @version 1.0
 *
 * @param zookeeper a boolean that indicates zookeeper role
 * @param admin a boolean that indicates administration role user role
 * @param vet a boolean that indicates the veterianain role
 */

public class PrintRole{
   private String userRole;
   private FileInputStream fileByteStream;
   private Scanner inFS;
   private boolean zookeeper;
   private boolean admin;
   private boolean vet;
   /* constructor to initialize private fields */
   public PrintRole(){
      userRole = "none";
      zookeeper = false;
      admin = false;
      vet = false;
      
   }
   /* getters and setters */
   public void setRole(String uRole){
      userRole = uRole;
   }
   public void setFileInputStream(FileInputStream fByte){
      fileByteStream = fByte;
   }
   public void setFS(Scanner inFS){
      this.inFS = inFS;
   }
   public boolean getKeeper(){
      return zookeeper;
   }
   public boolean getAdmin(){
      return admin;
   }
   public boolean getVet(){
      return vet;
   }
      
    /* print out user role */     
   public void rolePrinter()throws IOException, Exception{
   /**
    * This function takes a user title and prints out the user role
    *
    *@param userRole is the title of the user
    */
      switch(userRole){
      
      case "admin":
      FileInputStream adminFile = new FileInputStream("admin.txt");
      inFS = new Scanner(adminFile);
      admin = true;
      while(inFS.hasNextLine()){
        
         System.out.println(inFS.nextLine());
      }
      adminFile.close();
      break;
      
      case "zookeeper":
      FileInputStream zookeeperFile = new FileInputStream("zookeeper.txt");
      inFS = new Scanner(zookeeperFile);
      zookeeper = true;
      while(inFS.hasNextLine()){
         System.out.println(inFS.nextLine());
      }
      zookeeperFile.close();
      break;
      
      case "veterinarian":
      FileInputStream vetFile = new FileInputStream("veterinarian.txt");
      inFS = new Scanner(vetFile);
      vet = true;
      while(inFS.hasNextLine()){
          System.out.println(inFS.nextLine());
      }
      vetFile.close();
      break;
      
      default:
        break;
          
      }
    }

   

}